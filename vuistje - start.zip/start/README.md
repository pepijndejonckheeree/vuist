# Todo

- Gatsby project aanmaken
- template
- Contentful space + entities aanmaken
- gatsby-source-contentful plugin
- createPages
- git push
- Netlify automatic build
- Netlify webhook aanmaken
- Webhook aanroepen vanuit Contentful

---

- Netlify dev
- netlify.toml

---

- Form
- serverless function 'create'
- Data uit form ophalen
- uniek -kort- id genereren
- Contentful management API

---

- Routing

---

- Temporary view
- serverless request function
- Cache

# Resources

Gebaseerd op
https://vlolly.net/
https://github.com/philhawksworth/virtual-lolly

Netlify CLI
https://docs.netlify.com/cli/get-started/#installation

Netlify DEV
https://github.com/netlify/cli/blob/master/docs/netlify-dev.md

Netlify functions met JavaScript
https://docs.netlify.com/functions/build-with-javascript/

Functions functions functions
https://functions.netlify.com/

Contentful management API
https://www.contentful.com/developers/docs/references/content-management-api/#/reference/entries/entry/create-update-an-entry/console/js

local 404 redirects werken niet
https://github.com/netlify/cli/issues/753

Wes Bos caching trick:
https://theburningmonk.com/2019/10/all-you-need-to-know-about-caching-for-serverless-applications/

copy button
https://github.com/DSchau/gatsby/blob/d9905de374be1853c438a1d9dae74b47feb9e603/www/src/components/copy.js

Location prop in Gatsby
https://www.gatsbyjs.org/docs/location-data-from-props/
https://developer.mozilla.org/en-US/docs/Web/API/Location/origin

Ter info: dynamic static
https://www.gatsbyjs.org/blog/2018-12-17-turning-the-static-dynamic/
